package com.example.ejercicio7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Pantalla2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla2)
        val Informacion=findViewById<TextView>(R.id.tvResult)
        val nombre: String = intent.extras?.getString("EXTRA_NOMBRE").orEmpty()
        val apellido: String = intent.extras?.getString("EXTRA_APELLIDOS").orEmpty()
        val curso: String = intent.extras?.getString("EXTRA_CURSO").orEmpty()
        val asignatura: String = intent.extras?.getString("EXTRA_ASIGNATURA").orEmpty()
        val nota: String = intent.extras?.getString("EXTRA_NOTA").orEmpty()

        Informacion.text = "Hola $nombre" +
                "\nDetalles:" +
                "\nApellidos: $apellido" +
                "\nCurso: $curso" +
                "\nAsignatura: $asignatura" +
                "\nNota: $nota"
    }
}