package com.example.ejercicio7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.example.ejercicio7.R

class Pantalla1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla1)

        val btnPulsame = findViewById<AppCompatButton>(R.id.btnPulsame)
        val etNombre = findViewById<AppCompatEditText>(R.id.etNombre)
        val etApellidos = findViewById<AppCompatEditText>(R.id.etApellidos)
        val etCurso = findViewById<AppCompatEditText>(R.id.etCurso)
        val etAsignatura = findViewById<AppCompatEditText>(R.id.etAsignatura)
        val etNota = findViewById<AppCompatEditText>(R.id.etNota)


        btnPulsame.setOnClickListener {
            val nombre = etNombre.text.toString()   //Extraes aquí ese texto
            val apellidos = etApellidos.text.toString()
            val curso = etCurso.text.toString()
            val asignatura = etAsignatura.text.toString()
            val nota = etNota.text.toString()

            if (nombre.isNotEmpty()&&apellidos.isNotEmpty()&&curso.isNotEmpty()
                &&asignatura.isNotEmpty()&&nota.isNotEmpty()) {
                val intent = Intent(this, Pantalla2::class.java)
                intent.putExtra("EXTRA_NOMBRE", nombre)  //Guarda ese texto en un extra en el texto que se va a comunicar con la otra pantalla
                intent.putExtra("EXTRA_APELLIDOS", apellidos)
                intent.putExtra("EXTRA_CURSO", curso)
                intent.putExtra("EXTRA_ASIGNATURA", asignatura)
                intent.putExtra("EXTRA_NOTA", nota)
                startActivity(intent)
            }
        }
    }
}