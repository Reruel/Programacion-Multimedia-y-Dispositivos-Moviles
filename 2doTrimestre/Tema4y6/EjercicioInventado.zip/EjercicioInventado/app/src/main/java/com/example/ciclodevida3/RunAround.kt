package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class RunAround : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_runaround)
        Log.d("Lifecycle", "RunAround - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "RunAround - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "RunAround - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "RunAround - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "RunAround - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "RunAround - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "RunAround - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
