package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class MakeYouCry : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_makeyoucry)
        Log.d("Lifecycle", "MakeYouCry - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "MakeYouCry - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "MakeYouCry - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "MakeYouCry - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "MakeYouCry - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "MakeYouCry - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "MakeYouCry - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
