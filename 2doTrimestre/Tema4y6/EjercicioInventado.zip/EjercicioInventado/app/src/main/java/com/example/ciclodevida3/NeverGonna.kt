package com.example.ciclodevida3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity


class NeverGonna : AppCompatActivity() {
    var index = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nevergonna)
        Log.d("Lifecycle", "NeverGonna - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "NeverGonna - onStart")
    }
    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "NeverGonna - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "NeverGonna - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "NeverGonna - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "NeverGonna - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "NeverGonna - onDestroy")
    }

    fun goToNext(view: View) {
        if (index == 0) {
            val intent = Intent(this, GiveYouUp::class.java)
            startActivity(intent)
        } else if (index == 1) {
            val intent = Intent(this, LetYouDown::class.java)
            startActivity(intent)
        } else if (index == 2) {
            val intent = Intent(this, RunAround::class.java)
            startActivity(intent)
        } else if (index == 3) {
            val intent = Intent(this, MakeYouCry::class.java)
            startActivity(intent)
        } else if (index == 4) {
            val intent = Intent(this, SayGoodbye::class.java)
            startActivity(intent)
        } else if (index == 5) {
            val intent = Intent(this, TellALie::class.java)
            startActivity(intent)
        }
        if (index == 5) {
            index = 0
        } else {
            index++
        }
    }
}
