package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class TellALie : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tellalie)
        Log.d("Lifecycle", "TellALie - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "TellALie - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "TellALie - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "TellALie - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "TellALie - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "TellALie - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "TellALie - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
