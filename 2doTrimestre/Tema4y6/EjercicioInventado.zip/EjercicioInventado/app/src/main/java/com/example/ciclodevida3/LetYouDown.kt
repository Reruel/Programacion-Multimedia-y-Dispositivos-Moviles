package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class LetYouDown : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_letyoudown)
        Log.d("Lifecycle", "LetYouDown - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "LetYouDown - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "LetYouDown - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "LetYouDown - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "LetYouDown - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "LetYouDown - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "LetYouDown - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
