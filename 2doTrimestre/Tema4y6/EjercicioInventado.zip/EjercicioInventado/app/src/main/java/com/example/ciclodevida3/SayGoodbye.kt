package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class SayGoodbye : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saygoodbye)
        Log.d("Lifecycle", "SayGoodbye  - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "SayGoodbye - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "SayGoodbye - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "SayGoodbye - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "SayGoodbye - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "SayGoodbye - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "SayGoodbye - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
