package com.example.ciclodevida3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.view.View


class GiveYouUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giveyouup)
        Log.d("Lifecycle", "GiveYouUp - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "GiveYouUp - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "GiveYouUp - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "GiveYouUp - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "GiveYouUp - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "GiveYouUp - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "GiveYouUp - onDestroy")
    }

    fun goToNeverGonna(view: View) {
        finish()
    }
}
