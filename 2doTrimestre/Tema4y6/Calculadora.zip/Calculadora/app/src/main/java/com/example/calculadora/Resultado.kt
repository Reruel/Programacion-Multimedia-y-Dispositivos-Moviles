package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Resultado : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)
        val resultadoFinal=findViewById<TextView>(R.id.tvResult)
        val resultado: String = intent.extras?.getString("EXTRA_RESULTAO").orEmpty()

        resultadoFinal.text = "Po ta dao $resultado"


    }
}