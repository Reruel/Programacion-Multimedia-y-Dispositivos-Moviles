package com.example.calculadora

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText

class Principal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        val operador1 = findViewById<AppCompatEditText>(R.id.Op1)
        val operador2 = findViewById<AppCompatEditText>(R.id.Op2)

        val sumar = findViewById<AppCompatButton>(R.id.Sumar)
        val restar = findViewById<AppCompatButton>(R.id.Restar)
        val multiplicar = findViewById<AppCompatButton>(R.id.Multiplicar)
        val dividir = findViewById<AppCompatButton>(R.id.Dividir)

        sumar.setOnClickListener {
            val op1 =  operador1.text.toString()
            val op2 =  operador2.text.toString()

            if (op1.isNotEmpty()&&op2.isNotEmpty()){
                val resultao = op1.toDouble()+op2.toDouble()
                val intent = Intent(this, Resultado::class.java)
                intent.putExtra("EXTRA_RESULTAO", resultao.toString())
                startActivity(intent)
            }
        }

        restar.setOnClickListener {
            val op1 =  operador1.text.toString()
            val op2 =  operador2.text.toString()

            if (op1.isNotEmpty()&&op2.isNotEmpty()){
                val resultao = op1.toDouble()-op2.toDouble()
                val intent = Intent(this, Resultado::class.java)
                intent.putExtra("EXTRA_RESULTAO", resultao.toString())
                startActivity(intent)
            }
        }

        multiplicar.setOnClickListener {
            val op1 =  operador1.text.toString()
            val op2 =  operador2.text.toString()

            if (op1.isNotEmpty()&&op2.isNotEmpty()){
                val resultao = op1.toDouble()*op2.toDouble()
                val intent = Intent(this, Resultado::class.java)
                intent.putExtra("EXTRA_RESULTAO", resultao.toString())
                startActivity(intent)
            }
        }

        dividir.setOnClickListener {
            val op1 =  operador1.text.toString()
            val op2 =  operador2.text.toString()

            if (op1.isNotEmpty()&&op2.isNotEmpty()){
                val resultao = op1.toDouble()/op2.toDouble()
                val intent = Intent(this, Resultado::class.java)
                intent.putExtra("EXTRA_RESULTAO", resultao.toString())
                startActivity(intent)
            }
        }

    }
}





