package com.example.recycledviewej1
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val personList = generatePersonList()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val personAdapter = PersonAdapter(personList)
        recyclerView.adapter = personAdapter
    }

    private fun generatePersonList(): List<Person> {
        return listOf(
            return listOf(
                Person("Alberto","Fernandez"),
                Person("Juan","Diaz"),
                Person("Eva","Herrera"),
                Person("Alberto","Romero"),
                Person("Laura","Alvarez"),
                Person("Cristina","Suarez"),
                Person("Isabel","Sanchez"),
                Person("Pedro","Garcia"),
                Person("Jose","Romero"),
                Person("Manuel","Acosta"),
                Person("Diana","Benitez"),
                )
        )
    }
}
