package com.example.recycledviewej1

data class Person(val name: String, val apellido:String)
