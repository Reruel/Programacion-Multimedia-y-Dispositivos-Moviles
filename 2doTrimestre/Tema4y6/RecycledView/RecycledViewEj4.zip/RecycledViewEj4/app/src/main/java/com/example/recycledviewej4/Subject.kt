package com.example.recycledviewej4

data class Subject(val name: String) {
}