package com.example.recycledviewej4

data class Course(val name: String, val subjects: List<Subject>){
}