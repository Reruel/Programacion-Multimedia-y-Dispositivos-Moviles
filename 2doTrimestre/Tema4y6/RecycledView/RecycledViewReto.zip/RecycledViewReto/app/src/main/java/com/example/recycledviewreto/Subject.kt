package com.example.recycledviewreto

data class Subject(val name: String) {
}