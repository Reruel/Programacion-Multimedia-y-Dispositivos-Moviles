package com.example.recycledviewreto

data class Trabajos(val name: String, val subjects: List<Subject>){
}