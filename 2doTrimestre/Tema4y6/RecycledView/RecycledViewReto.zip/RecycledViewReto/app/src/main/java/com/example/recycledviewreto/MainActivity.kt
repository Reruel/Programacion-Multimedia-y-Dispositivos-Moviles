package com.example.recycledviewreto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

val courses = listOf(
    Trabajos("Programación", listOf(Subject("Programador en Android"), Subject("Gestor de BBDD"), Subject("Programador en Java"))),
    Trabajos("Diseño web", listOf(Subject("Especialista en Wordpress"), Subject("Técnico de Javascript"), Subject("Especialista en PHP"))),
    Trabajos("Marketing digital", listOf(Subject("Especialista en SEO"), Subject("Técnico en SEM"), Subject("Especialista en Redes Sociales")))

)

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerViewCourses: RecyclerView = findViewById(R.id.recyclerViewCourses)
        recyclerViewCourses.layoutManager = LinearLayoutManager(this)
        recyclerViewCourses.adapter = CourseAdapter(courses) { course ->
            showSubjectsDialog(course)
        }
    }

    private fun showSubjectsDialog(course: Trabajos) {
        val subjects = course.subjects.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Asignaturas de ${course.name}")
            .setItems(subjects) { _, _ ->
                // Acción al hacer clic en una asignatura (puedes implementar algo aquí)
            }
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }
}