package com.example.recycledviewreto

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CourseAdapter(private val trabajos: List<Trabajos>, private val onCourseClickListener: (Trabajos) -> Unit) :
    RecyclerView.Adapter<CourseAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_trabajo, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trabajo = trabajos[position]

        // Aquí es donde debes obtener el TextView dentro de la vista.item_trabajo.xml
        val courseTextView: TextView = holder.itemView.findViewById(R.id.courseNameTextView)

        // Ahora, establece el texto en el TextView
        courseTextView.text = trabajo.name

        // Asigna el clic al itemView (puede seguir usándolo si es necesario)
        holder.itemView.setOnClickListener { onCourseClickListener(trabajo) }
    }

    override fun getItemCount(): Int = trabajos.size
}