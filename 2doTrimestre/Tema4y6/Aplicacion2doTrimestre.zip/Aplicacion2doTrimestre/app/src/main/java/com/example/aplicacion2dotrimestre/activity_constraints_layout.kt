package com.example.aplicacion2dotrimestre

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_constraints_layout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_constraints_layout)
    }
}