package com.example.calculadorapro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button0 = findViewById<Button>(R.id.button0)
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)
        val button5 = findViewById<Button>(R.id.button5)
        val button6 = findViewById<Button>(R.id.button6)
        val button7 = findViewById<Button>(R.id.button7)
        val button8 = findViewById<Button>(R.id.button8)
        val button9 = findViewById<Button>(R.id.button9)
        val buttonPlus = findViewById<Button>(R.id.buttonPlus)
        val buttonMinus = findViewById<Button>(R.id.buttonMinus)
        val buttonMultiply = findViewById<Button>(R.id.buttonMultiply)
        val buttonDivide = findViewById<Button>(R.id.buttonDivide)
        val buttonClear = findViewById<Button>(R.id.buttonClear)
        val buttonEqual = findViewById<Button>(R.id.buttonEqual)

        button0.setOnClickListener(this)
        button1.setOnClickListener(this)
        button2.setOnClickListener(this)
        button3.setOnClickListener(this)
        button4.setOnClickListener(this)
        button5.setOnClickListener(this)
        button6.setOnClickListener(this)
        button7.setOnClickListener(this)
        button8.setOnClickListener(this)
        button9.setOnClickListener(this)
        buttonPlus.setOnClickListener(this)
        buttonMinus.setOnClickListener(this)
        buttonMultiply.setOnClickListener(this)
        buttonDivide.setOnClickListener(this)
        buttonClear.setOnClickListener(this)
        buttonEqual.setOnClickListener(this)

    }

    var equOnScreen: String? = null

    override fun onClick(p0: View?) {
        val resultOnScreen = findViewById<TextView>(R.id.resultOnScreen)
        val message: String = "Please write two numbers and an operator between them"
        if(equOnScreen.isNullOrBlank() || equOnScreen == message) {
            equOnScreen = ""
        }

        when (p0?.id) {
            R.id.button0 -> equOnScreen = "$equOnScreen" + "0" + " "
            R.id.button1 -> equOnScreen = "$equOnScreen" + "1" + " "
            R.id.button2 -> equOnScreen = "$equOnScreen" + "2" + " "
            R.id.button3 -> equOnScreen = "$equOnScreen" + "3" + " "
            R.id.button4 -> equOnScreen = "$equOnScreen" + "4" + " "
            R.id.button5 -> equOnScreen = "$equOnScreen" + "5" + " "
            R.id.button6 -> equOnScreen = "$equOnScreen" + "6" + " "
            R.id.button7 -> equOnScreen = "$equOnScreen" + "7" + " "
            R.id.button8 -> equOnScreen = "$equOnScreen" + "8" + " "
            R.id.button9 -> equOnScreen = "$equOnScreen" + "9" + " "
            R.id.buttonPlus -> equOnScreen = "$equOnScreen" + "+" + " "
            R.id.buttonMinus -> equOnScreen = "$equOnScreen" + "-" + " "
            R.id.buttonMultiply -> equOnScreen = "$equOnScreen" + "*" + " "
            R.id.buttonDivide -> equOnScreen = "$equOnScreen" + "/" + " "
            R.id.buttonClear ->  equOnScreen = ""
            R.id.buttonEqual -> {

                if(stringdataIntoCalc(equOnScreen!!) != null) {
                    equOnScreen = stringdataIntoCalc(equOnScreen!!).toString() + " "
                }
                else equOnScreen = message


            }
        }
        resultOnScreen.text = equOnScreen

    }

    fun stringdataIntoCalc(string : String) : Int? {
        var stringList : MutableList<String>  = string.split(" ").toMutableList()
        if(stringList.size != 4) {return null}
        var first : String = stringList[0]
        var second : String = stringList[2]
        var sign : String = stringList[1]
        var result : Int? = null

        when(sign) {
            "+" -> result =  first.toInt() + second.toInt()
            "-" -> result = first.toInt() - second.toInt()
            "*" -> result = first.toInt() * second.toInt()
            "/" -> result = first.toInt() / second.toInt()
        }

        if(result != null) {
            return result
        }
        return null
    }

}