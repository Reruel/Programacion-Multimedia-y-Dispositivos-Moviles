package com.example.tema8.Ejercicio2

data class Alumno(val nombre: String)