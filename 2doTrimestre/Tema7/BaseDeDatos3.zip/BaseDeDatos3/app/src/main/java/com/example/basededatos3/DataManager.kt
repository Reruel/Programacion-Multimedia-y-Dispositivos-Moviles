package com.example.basededatos3

import android.content.ContentValues
import android.content.Context
import android.widget.Toast

class DataManager(context: Context) {
    /*creamos una instancia de DatabaseHelper y le añadimos el contexto, es decir acceso a recursos, base de datos, etc */
    private val dbHelper = DatabaseHelper(context)

    fun addUser(nombre: String, apellidos: String, dni: String, edad: String, curso: String) {
        val db = dbHelper.writableDatabase   //usamos el método par //escribir en la bbdd

        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_NOMBRE, nombre)
            put(DatabaseHelper.COLUMN_APELLIDOS, apellidos)
            put(DatabaseHelper.COLUMN_DNI, dni)
            put(DatabaseHelper.COLUMN_EDAD, edad)
            put(DatabaseHelper.COLUMN_CURSO, curso)
        }
        db.insert(DatabaseHelper.TABLE_NAME, null, values)
        db.close()
    }
    //rawQuery crea una consulta y la devuelve en un cursor
    fun getAllNames(context: Context): String {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_NAME}", null)
        val names = StringBuilder()

        while (cursor.moveToNext()) {
            val nombre = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NOMBRE))
            val apellidos = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_APELLIDOS))
            val dni = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DNI))
            val edad = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EDAD))
            val curso = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_CURSO))
            names.append("$nombre - $apellidos - $dni- $edad- $curso\n")

        }

        cursor.close()
        db.close()

        if (names.isEmpty()) {
            return "No hay nombres en la base de datos"
        }

        return names.toString()
    }
}