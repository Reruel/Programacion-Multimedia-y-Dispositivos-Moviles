package com.example.retoalmacenamiento

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnLeerArchivo: Button = findViewById(R.id.btnLeer)
        val tv: TextView = findViewById(R.id.tvText)
        val btnCrearArchivo: Button = findViewById(R.id.btnCrear)

        btnCrearArchivo.setOnClickListener {
            crearArchivo()
        }

        btnLeerArchivo.setOnClickListener {
            leerArchivo(tv)
        }
    }
    private fun crearArchivo() {
        try {
            val fileName = "Alberto el grande"
            val fileContent = "Alberto imperator"

            // Abrir un OutputStreamWriter en el modo privado (solo accesible por esta aplicación)
            var osw: OutputStreamWriter = OutputStreamWriter(openFileOutput(fileName, MODE_PRIVATE))

            // Escribir el contenido en el archivo
            osw.write(fileContent)

            // Limpiar y cerrar el OutputStreamWriter
            osw.flush() //limpiamos
            osw.close() //cerramos

            Log.d("Éxito", "Archivo creado con éxito!")

        } catch (e: Exception) {
            Log.e("Error", "Error al usar OutputStreamWriter: " + e.message)
        }
    }
    private fun leerArchivo(tv: TextView) {
        try {
            val fileName = "Alberto el grande"

            // Abrir un BufferedReader para leer el archivo
            val br = BufferedReader(InputStreamReader(openFileInput(fileName)))

            // Leer la primera línea del archivo
            val texto = br.readLine()

            // Cerrar el BufferedReader
            br.close()

            Log.d("Éxito", "Contenido del archivo: $texto")
            tv.text="El texto es: $texto"

        } catch (e: Exception) {
            Log.e("Error", "Error al leer el archivo: " + e.message)
            tv.text="Error al leer el archivo"
        }
    }
}