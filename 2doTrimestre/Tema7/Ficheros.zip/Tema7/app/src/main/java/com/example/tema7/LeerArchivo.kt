package com.example.tema7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import android.util.Log
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader

class LeerArchivo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leer_archivo)
        val btnLeerArchivo: Button = findViewById(R.id.btnLeerArchivo)
        val tv:TextView = findViewById(R.id.tvRes)


        btnLeerArchivo.setOnClickListener {
            leerArchivo(tv)
        }
    }

    private fun leerArchivo(tv: TextView) {
        try {
            val fileName = "Alberto el grande"

            // Abrir un BufferedReader para leer el archivo
            val br = BufferedReader(InputStreamReader(openFileInput(fileName)))

            // Leer la primera línea del archivo
            val texto = br.readLine()

            // Cerrar el BufferedReader
            br.close()

            Log.d("Éxito", "Contenido del archivo: $texto")
            tv.text="El texto es: $texto"

        } catch (e: Exception) {
            Log.e("Error", "Error al leer el archivo: " + e.message)
            tv.text="Error al leer el archivo"
        }
    }
}
