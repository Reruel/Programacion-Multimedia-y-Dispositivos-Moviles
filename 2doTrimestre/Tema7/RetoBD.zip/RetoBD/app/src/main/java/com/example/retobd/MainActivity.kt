package com.example.retobd

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var dataManager: DataManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataManager = DataManager(this)

        //nombre, apellidos, dni, edad, curso,

        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etApellidos = findViewById<EditText>(R.id.etApellidos)
        val etDni = findViewById<EditText>(R.id.etDni)
        val etEdad = findViewById<EditText>(R.id.etEdad)
        val etCurso = findViewById<EditText>(R.id.etCurso)

        val btnAgregar = findViewById<Button>(R.id.btnAgregar)
        val btnMostrar = findViewById<Button>(R.id.btnMostrar)
        val tvMuestraNombre = findViewById<TextView>(R.id.tvMuestraNombre)
        val btnEliminar = findViewById<Button>(R.id.btnEliminar)
        val btnModificar = findViewById<Button>(R.id.btnModificar)

        btnAgregar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val apellidos = etApellidos.text.toString()
            val dni = etDni.text.toString()
            val edad = etEdad.text.toString()
            val curso = etCurso.text.toString()
            dataManager.addUser(nombre, apellidos, dni, edad, curso)
            Toast.makeText(this, "Se agregó a la base de datos: $nombre", Toast.LENGTH_SHORT).show()
            etNombre.text.clear() //limpiamos el compononente editext
            etApellidos.text.clear() //Para que no se queden guardados los datos
            etDni.text.clear() //Para que no se queden guardados los datos
            etEdad.text.clear() //Para que no se queden guardados los datos
            etCurso.text.clear() //Para que no se queden guardados los datos
        }

        // muestra todos los datos
        btnMostrar.setOnClickListener {
            // estamos instanciando la clase datamanager
            val nombres = dataManager.getAllNames(this)
            tvMuestraNombre.text = nombres //nos muestra los nombres que hay en la tabla
        }

        btnModificar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val apellidos = etApellidos.text.toString()
            val dni = etDni.text.toString()
            val edad = etEdad.text.toString()
            val curso = etCurso.text.toString()
            dataManager.modify(nombre, apellidos, dni, edad, curso)
            Toast.makeText(this, "Se modificó en la base de datos: $dni", Toast.LENGTH_SHORT).show()
            etNombre.text.clear() //limpiamos el compononente editext
            etApellidos.text.clear() //Para que no se queden guardados los datos
            etDni.text.clear() //Para que no se queden guardados los datos
            etEdad.text.clear() //Para que no se queden guardados los datos
            etCurso.text.clear() //Para que no se queden guardados los datos
        }

        btnEliminar.setOnClickListener {
            val nombre = etNombre.text.toString()
            dataManager.eliminate(nombre)
            Toast.makeText(this, "Se eliminó a la base de datos: $nombre", Toast.LENGTH_SHORT).show()
            etNombre.text.clear() //limpiamos el compononente editext
        }
    }
}