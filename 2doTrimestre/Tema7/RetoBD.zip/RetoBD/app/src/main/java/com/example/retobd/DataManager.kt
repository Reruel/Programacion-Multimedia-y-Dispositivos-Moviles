package com.example.retobd

import android.content.ContentValues
import android.content.Context

class DataManager(context: Context) {
    /*creamos una instancia de DatabaseHelper y le añadimos el contexto, es decir acceso a recursos, base de datos, etc */
    private val dbHelper = DataBaseHelper(context)

    fun addUser(nombre: String, apellidos: String, dni: String, edad: String, curso: String) { //Función insertar
        val db = dbHelper.writableDatabase   //usamos el método par //escribir en la bbdd

        val values = ContentValues().apply {
            put(DataBaseHelper.COLUMN_NOMBRE, nombre)
            put(DataBaseHelper.COLUMN_APELLIDOS, apellidos)
            put(DataBaseHelper.COLUMN_DNI, dni)
            put(DataBaseHelper.COLUMN_EDAD, edad)
            put(DataBaseHelper.COLUMN_CURSO, curso)
        }
        db.insert(DataBaseHelper.TABLE_NAME, null, values)
        db.close()
    }
    //rawQuery crea una consulta y la devuelve en un cursor
    fun getAllNames(context: Context): String {  //Función mostrar
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${DataBaseHelper.TABLE_NAME}", null)
        val names = StringBuilder()

        while (cursor.moveToNext()) {
            val nombre = cursor.getString(cursor.getColumnIndex(DataBaseHelper.COLUMN_NOMBRE))
            val apellidos = cursor.getString(cursor.getColumnIndex(DataBaseHelper.COLUMN_APELLIDOS))
            val dni = cursor.getString(cursor.getColumnIndex(DataBaseHelper.COLUMN_DNI))
            val edad = cursor.getString(cursor.getColumnIndex(DataBaseHelper.COLUMN_EDAD))
            val curso = cursor.getString(cursor.getColumnIndex(DataBaseHelper.COLUMN_CURSO))
            names.append("$nombre - $apellidos - $dni- $edad- $curso\n")

        }

        cursor.close()
        db.close()

        if (names.isEmpty()) {
            return "No hay nombres en la base de datos"
        }

        return names.toString()
    }

    fun eliminate(nombre:String) {
        val db = dbHelper.writableDatabase

        db.execSQL("DELETE FROM ${DataBaseHelper.TABLE_NAME} WHERE ${DataBaseHelper.COLUMN_NOMBRE}='$nombre'")
        db.close()
    }

    fun modify(nombre: String, apellidos: String, dni: String, edad: String, curso: String) {
        val db = dbHelper.writableDatabase

        db.execSQL("UPDATE ${DataBaseHelper.TABLE_NAME} SET ${DataBaseHelper.COLUMN_NOMBRE}='$nombre', " +
                "${DataBaseHelper.COLUMN_APELLIDOS}='$apellidos'," +
                "${DataBaseHelper.COLUMN_EDAD}='$edad'," +
                "${DataBaseHelper.COLUMN_CURSO}='$curso' " +
                "WHERE ${DataBaseHelper.COLUMN_DNI}='$dni'")
        db.close()
    }
}