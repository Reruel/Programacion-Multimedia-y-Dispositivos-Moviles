package com.example.citamedica

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.marginLeft


class Cita : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cita)

        val rootView: View = LayoutInflater.from(this).inflate(R.layout.activity_cita, null)

        val linearLayout = rootView.findViewById<LinearLayout>(R.id.dataList)

        val nombre = TextView(this)
        nombre.setText("Nombre: \n${intent.getStringExtra("EXTRA_NOMBRE")}")
        nombre.textSize = 25F
        val especialista = TextView(this)
        especialista.setText("Especialista: \n${intent.getStringExtra("EXTRA_ESPECIALISTA")}")
        especialista.textSize = 25F
        val fecha = TextView(this)
        fecha.setText("Fecha: \n${intent.getStringExtra("EXTRA_FECHA")}")
        fecha.textSize = 25F
        val citaUrg = TextView(this)
        citaUrg.setText("\n${intent.getStringExtra("EXTRA_CITA")}")
        citaUrg.textSize = 30F

        val toast = Toast.makeText(this,"Su cita ha sido guardada correctamente", Toast. LENGTH_LONG)
        toast.show()



        linearLayout.addView(nombre)
        linearLayout.addView(especialista)
        linearLayout.addView(fecha)
        linearLayout.addView(citaUrg)



        setContentView(rootView)
    }
}


