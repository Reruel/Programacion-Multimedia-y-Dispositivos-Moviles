package com.example.citamedica

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView


class MainActivity : AppCompatActivity() {
    var opcionSeleccionada: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        setContentView(R.layout.activity_main)
        val duration = Toast.LENGTH_SHORT
        val nombre = findViewById<EditText>(R.id.Nombre)
        val especialista = findViewById<EditText>(R.id.Especialista)
        val fecha = findViewById<EditText>(R.id.Fecha)
        val citaUrgente = findViewById<CardView>(R.id.CitaUrgente)
        val entrar = findViewById<Button>(R.id.Entrar)


        entrar.setOnClickListener {
            val infonombre = nombre.text.toString()
            val infoespecialista = especialista.text.toString()
            val infofecha = fecha.text.toString()


            if (infonombre.isNotEmpty() && infoespecialista.isNotEmpty() && infofecha.isNotEmpty()) {
                val intent = Intent(this, Cita::class.java)
                intent.putExtra("EXTRA_NOMBRE", infonombre)
                intent.putExtra("EXTRA_ESPECIALISTA", infoespecialista)
                intent.putExtra("EXTRA_FECHA", infofecha)
                intent.putExtra("EXTRA_CITA", opcionSeleccionada)
                startActivity(intent)
            }
        }
        citaUrgente.setOnClickListener {
            handleCardViewClick(citaUrgente)
        }
    }

    fun handleCardViewClick(cardView: CardView) {
        when (cardView.id) {
            R.id.CitaUrgente -> {
                opcionSeleccionada = "CITA URGENTE SOLICITADA"
                Log.d("CitaMedica", "MainActivity - handleCardViewclick")
            }
        }
    }
}