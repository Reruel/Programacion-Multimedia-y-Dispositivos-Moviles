class prueba {
    fun main(args: Array){
        println("Hola mundo");
    }
}