package com.example.myapplication1.paquete1

fun main(){
    println("Hola mundo!")
    var valor1 = 2
    var valor2:Int=3
    var resultado:Int = valor1+valor2
    println("El resultado de $valor1 + $valor2 es $resultado")
    resultado = valor1 * valor2
    println("El resultado de $valor1 * $valor2 es $resultado")
    resultado = valor2/valor1
    println("El resultado de $valor1 / $valor2 es $resultado")
    resultado = valor2-valor1
    println("El resultado de $valor2 - $valor1 es $resultado")


}