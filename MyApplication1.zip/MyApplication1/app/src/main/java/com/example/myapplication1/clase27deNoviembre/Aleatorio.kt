package com.example.myapplication1.clase27deNoviembre

import kotlin.random.Random

fun main(){
    var r = Random.nextInt(0,4)
    println("Número aleatorio elegido: $r")
}