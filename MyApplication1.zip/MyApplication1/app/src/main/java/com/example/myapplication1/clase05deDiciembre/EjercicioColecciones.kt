package com.example.myapplication1.clase05deDiciembre

fun main(){
    var col:List<Int>
    col = listOf(1,2,3,4,5,6)

    val primerElemento = col[0]
    println("El primer elemento es $primerElemento")
    for (element in col){
        println(element)
    }

    var col2 = mutableListOf<Any>("a",1,"b",2)
    col2.add(1,57)
    for (element in col2){
        println(element)
    }
}