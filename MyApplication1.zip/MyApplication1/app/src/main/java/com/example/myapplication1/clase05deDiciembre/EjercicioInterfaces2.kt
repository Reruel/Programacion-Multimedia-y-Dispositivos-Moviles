package com.example.myapplication1.clase05deDiciembre

interface Persona {
    val nombre:String
    val edad:Int

    fun presentacion()
}

class Alumno(override val nombre:String,override val edad:Int, val grado:String):Persona{
    override fun presentacion() {
        println("Soy el alumno: $nombre\n" +
                "Edad: $edad\n" +
                "Grado: $grado")
    }
    fun estudiar(){
        println("$nombre está estudiando")
    }

}
class Profesor(override val nombre:String,override val edad:Int, val asignatura:String):Persona{
    override fun presentacion() {
        println("Soy el profesor: $nombre\n" +
                "Edad: $edad\n" +
                "Asignatura: $asignatura")
    }
    fun darClase(){
        println("$nombre está dando clase")
    }
}
fun main(){
    val alumno = Alumno("Juani", 19, "2ªDAM")
    val profesor = Profesor("Alberto",40,"Programacion multimedia")

    alumno.presentacion()
    println()
    profesor.presentacion()
    println()
    alumno.estudiar()
    profesor.darClase()
}