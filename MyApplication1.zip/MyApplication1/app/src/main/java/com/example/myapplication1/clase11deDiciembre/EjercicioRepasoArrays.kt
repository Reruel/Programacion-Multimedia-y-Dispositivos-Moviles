package com.example.myapplication1.clase11deDiciembre

fun main(){
    val matriz =arrayOf(intArrayOf(1,2,3), arrayOf("Juani","nombre2"), floatArrayOf(800.21f,760.45f,876.32f))
    val nombres = matriz[1] as Array<Any>
    println("Nombres ${nombres.joinToString(", ")}")
    val importes = matriz[2] as FloatArray
    val sumaImportes = importes.sum()
    println("La suma de importes es: $sumaImportes")
}