package com.example.myapplication1.clase04deDiciembre

open class Personaje (var nombre:String, var nivel:Int){
    open fun atacar(){
        println("$nombre realiza un ataque básico")
    }
    fun subirNivel(){
        nivel++
        println("$nombre ha subido al nivel $nivel")
    }
}
class Guerrero (nombre:String, nivel:Int, val arma:String) : Personaje(nombre, nivel){
    override fun atacar() {
        println("$nombre realiza un ataque básico con su $arma")
    }
    fun usarHabilidadEspecial(){
        println("$nombre realiza su habilidad especial de guerrero")
    }
}
class Mago(nombre:String, nivel:Int, val hechizo:String) : Personaje(nombre, nivel){
    override fun atacar() {
        println("$nombre realiza un ataque básico con su hechizo $hechizo")
    }
    fun lanzarHechizo(){
        println("$nombre lanza un hechizo de mago")
    }
}
fun main(){
    val guerrero = Guerrero("Warrior", 1, "espada grande")
    val mago = Mago("Wizard", 3, "bola de fuego")

    guerrero.atacar()
    guerrero.usarHabilidadEspecial()
    guerrero.subirNivel()

    println()

    mago.atacar()
    mago.lanzarHechizo()
    mago.subirNivel()
}