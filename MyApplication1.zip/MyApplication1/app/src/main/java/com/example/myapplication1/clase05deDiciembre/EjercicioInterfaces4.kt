package com.example.myapplication1.clase05deDiciembre

interface PersonaCliente{
    val nombre:String
    val edad:Int
    fun presentarse()
}
interface Cliente{
    val numeroCliente:String
    fun realizarCompra()
}

class ClientePremium(override val nombre:String,override val edad:Int,override val numeroCliente:String)
    :PersonaCliente,Cliente {
    override fun presentarse() {
        println("Nombre: $nombre\n" +
                "Edad: $edad\n" +
                "Número cliente: $numeroCliente")
    }

    override fun realizarCompra() {
        println("Cliente $numeroCliente realiza una compra")
    }
}
fun main() {
    val cliente1 = ClientePremium("Juani", 19, "23948")
    cliente1.presentarse()
    cliente1.realizarCompra()
}