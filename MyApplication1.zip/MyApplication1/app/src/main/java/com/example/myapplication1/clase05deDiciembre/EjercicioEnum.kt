package com.example.myapplication1.clase05deDiciembre

enum class Dias{
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
}
fun main(){
    val dia = Dias.LUNES
    when(dia){
        Dias.LUNES -> println("Es lunes")
        Dias.MARTES -> println("Es martes")
        Dias.MIERCOLES -> println("Es miércoles")
        Dias.JUEVES -> println("Es jueves")
        Dias.VIERNES -> println("Es viernes")
        Dias.SABADO -> println("Es sábado")
        Dias.DOMINGO -> println("Es domingo")
    }
}