package com.example.myapplication1.clase11deDiciembre

fun mostrar (lista : List<Any>){
    for(elemento in lista){
        println(elemento)
    }
}
fun main(){
    var centro:MutableList<Any>
    centro = mutableListOf("Matemáticas", "Alberto",5,"Lengua","Laura",6)
    println("Lista original: ")
    mostrar(centro)
    println()

    centro[0] = "Historia"
    centro[3] = "Física"
    println("Lista modificada 1: ")
    mostrar(centro)
    println()

    centro.add("Química")
    centro.add("Cristina")
    centro.add(7)
    println("Lista modificada 2: ")
    mostrar(centro)
}