package com.example.myapplication1.clase05deDiciembre

interface ProductosElectronicos{
    val nombre: String
    val fabricante: String
    val precio: Double
    // Métodos de la interfaz
    fun encender()
    fun apagar()
}


class Televisor (override val nombre:String, override val fabricante:String,
                 override val precio:Double): ProductosElectronicos{
    override fun encender() {
        println("El $nombre se encendió")
    }

    override fun apagar() {
        println("El $nombre se apagó")
    }
}
class Movil(override val nombre:String, override val fabricante:String,
            override val precio:Double): ProductosElectronicos{
    override fun apagar() {
        println("El movil $nombre se encendió")
    }

    override fun encender() {
        println("El movil $nombre se apagó")
    }
}

fun main() {
// Crear una instancia de la clase Televisor
    val miTelevisor = Televisor("Smart TV ", "Samsung", 799.99)
    val miMovil = Movil("Redmi note 13", "Xiaomi", 399.99)
// Acceder a las propiedades y métodos de la interfaz
    println("Nombre: ${ miTelevisor.nombre }")
    println("Fabricante: ${ miTelevisor.fabricante }")
    println("Precio: ${ miTelevisor.precio } €")

    println("Nombre: ${ miMovil.nombre }")
    println("Fabricante: ${ miMovil.fabricante }")
    println("Precio: ${ miMovil.precio } €")
// Llamar a los métodos encender() y apagar()

    miTelevisor.encender()
    miTelevisor.apagar()
    miMovil.encender()
    miMovil.apagar()
}