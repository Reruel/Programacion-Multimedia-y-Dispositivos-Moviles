package com.example.myapplication1.clase04deDiciembre

import kotlin.random.Random

open class Espia(val nombre:String) {
}
class Mision(nombre:String) : Espia(nombre){
    val contrasenia = Array<Int>(5, {i -> Random.nextInt(0,10) })
    var res:String =""

    fun generarContrasenia(){
        //for (i in 0..4){
          //  contrasenia[i] = Random.nextInt(0,10)
        //}
        println("Contraseña generada con exito")
    }

    fun compararContrasenia(insertada:String):String{
        val contraseniaInsertada = insertada.split(" ").toTypedArray()
        val conInToInt = Array<Int>(5,{i ->Integer.parseInt(contraseniaInsertada[i])})
        res = ""

        for(i in 0..contraseniaInsertada.size -1){
            if(contrasenia[i] > conInToInt [i]){
                res += ">"
            }else if (contrasenia[i] < conInToInt [i]){
                res +="<"
            }else if (contrasenia[i] == conInToInt [i]){
                res+="="
            }
        }
        if (res.equals("=====")){
            res = "Resolviste la clave"
        }
        return res
    }

    fun juegoTerminado(resultado:String):Boolean{
        if(resultado.equals("Resolviste la clave")){
            return true
        }
            return false
    }

}
fun main(){
    val mision = Mision("Juani")
    mision.generarContrasenia()
    for(i in 0..4){
        println(mision.contrasenia[i])
    }

    do{
        println("Ingresa una contraseña de 5 digitos separados por espacio")
        var insertada = readln()
        var resultado = mision.compararContrasenia(insertada)
        println(resultado)
        var r = mision.juegoTerminado(resultado)
        println()
    }while(!r)

}