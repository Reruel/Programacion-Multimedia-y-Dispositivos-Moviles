package com.example.myapplication1.clase04deDiciembre

open class ProductosInformaticos(val nombre:String, val precio:Int) {
    fun encender(){
        println("El producto $nombre se encendió")
    }
    fun apagar(){
        println("El producto $nombre se apagó")
    }
    open fun ejecutar(){
        println("El producto $nombre se está ejecutando")
    }
}
class Laptop(nombre:String,precio:Int, val marca:String):ProductosInformaticos(nombre,precio){
    override fun ejecutar() {
        println("La laptop $nombre se está ejecutando")
    }
}
class Impresora(nombre:String,precio:Int, val tipo:String) : ProductosInformaticos(nombre,precio){
    fun imprimir(){
        println("La impresora $nombre está imprimiendo")
    }
}
fun main(){
    val laptop = Laptop("Laptop1", 25,"marca1")
    val impresora = Impresora("Impresora1", 22, "marca2")
    laptop.encender()
    laptop.apagar()
    laptop.ejecutar()
    println()
    impresora.encender()
    impresora.apagar()
    impresora.ejecutar()
    impresora.imprimir()
}