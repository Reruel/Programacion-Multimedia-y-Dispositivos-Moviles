package com.example.myapplication1.clase05deDiciembre

interface Trabajador{
    val nombre:String
    val edad:Int
    fun trabajar()
}
class Empleado(override val nombre:String,override val edad:Int, val cargo:String):Trabajador {
    override fun trabajar() {
        println("$nombre está realizando tareas como $cargo")
    }
    fun tomarDescanso(){
        println("$nombre está tomando un descanso")
    }
}
class Jefe(override val nombre:String,override val edad:Int, val departamento:String):Trabajador
{
    override fun trabajar() {
        println("$nombre está supervisando el departamento $departamento")
    }
    fun realizarReuniones() {
        println("$nombre está llevando a cabo reuniones con el equipo")
    }
}
fun main() {
// Crear instancias de Empleado y Jefe
    val empleado1 = Empleado("Ana", 25, "Desarrollador")
    val jefe1 = Jefe("Sr. Rodríguez", 40, "Ventas")
// Llamar a métodos y propiedades comunes de la interfaz
    empleado1.trabajar()
    jefe1.trabajar()
// Llamar a métodos específicos de Empleado y Jefe
    empleado1.tomarDescanso()
    jefe1.realizarReuniones()
}