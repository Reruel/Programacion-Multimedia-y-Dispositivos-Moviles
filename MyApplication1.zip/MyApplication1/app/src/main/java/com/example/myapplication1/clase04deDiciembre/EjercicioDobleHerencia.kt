package com.example.myapplication1.clase04deDiciembre

open class Producto(val nombre:String, val precio:Int){
    fun mostrarDetalle(){
        println("Nombre producto: $nombre \nPrecio: $precio")
    }
}
open class Envio(nombre:String, precio:Int, val destino:String) : Producto(nombre,precio){
    fun calcularCostoEnvio():Float{
        return precio*0.10f
    }

    fun mostrarDetalleEnvio(){
        println("Nombre producto: $nombre \nPrecio: $precio\n" +
                "Destino: $destino\nPrecioEnvio: ${calcularCostoEnvio()}")
    }
}
class Factura(nombre:String, precio:Int, destino:String,val numeroFactura:Int): Envio(nombre,precio,destino){
    fun imprimirFactura(){
        println("Nombre producto: $nombre \nPrecio: $precio\n" +
                "Destino: $destino\nPrecioEnvio: ${calcularCostoEnvio()}\n" +
                "Numero de factura: $numeroFactura")
    }
}
fun main(){
    val factura = Factura("Laptop", 675,"Malaga centro", 124578)
    factura.imprimirFactura()
}